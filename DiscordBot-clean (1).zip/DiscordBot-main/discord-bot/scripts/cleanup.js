// One-off cleanup: deletes every role and every channel/category that is NOT
// in the keep-list below. Dry run by default; add --confirm to really delete.
//
//   node scripts/cleanup.js            (shows what WOULD be deleted)
//   node scripts/cleanup.js --confirm  (deletes it)
//
// Needs DISCORD_TOKEN and GUILD_ID in .env. The bot needs Manage Channels +
// Manage Roles, and its own role must sit ABOVE the roles it should delete.
require('dotenv').config();
const { Client, GatewayIntentBits, ChannelType } = require('discord.js');

const CONFIRM = process.argv.includes('--confirm');

const KEEP_CATEGORIES = ['chill-zone', 'rdr2-online', 'voice'];
const KEEP_CHANNELS = [
  'welcome', 'general',
  'info', 'rdr2-chat', 'tabara',
  'music', 'gaming-voice', 'general-voice', 'cuibusor', 'afk',
];

const SMALL_CAPS_REVERSE = {
  'ᴀ': 'a', 'ʙ': 'b', 'ᴄ': 'c', 'ᴅ': 'd', 'ᴇ': 'e', 'ꜰ': 'f', 'ɢ': 'g', 'ʜ': 'h',
  'ɪ': 'i', 'ᴊ': 'j', 'ᴋ': 'k', 'ʟ': 'l', 'ᴍ': 'm', 'ɴ': 'n', 'ᴏ': 'o', 'ᴘ': 'p',
  'ʀ': 'r', 'ꜱ': 's', 'ᴛ': 't', 'ᴜ': 'u', 'ᴠ': 'v', 'ᴡ': 'w', 'ʏ': 'y', 'ᴢ': 'z',
};
function nameKey(name) {
  let n = name.includes('・') ? name.split('・').slice(1).join('・') : name;
  n = [...n].map((c) => SMALL_CAPS_REVERSE[c] ?? c).join('');
  return n.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once('ready', async () => {
  const guild = await client.guilds.fetch(process.env.GUILD_ID);
  const channels = await guild.channels.fetch();
  const roles = await guild.roles.fetch();

  const toDeleteChannels = [...channels.values()].filter((c) => {
    if (!c) return false;
    if (c.type === ChannelType.GuildCategory) return !KEEP_CATEGORIES.includes(nameKey(c.name));
    return !KEEP_CHANNELS.includes(nameKey(c.name));
  });
  const toDeleteRoles = [...roles.values()].filter(
    (r) => r.id !== guild.id && !r.managed && r.editable
  );
  const skippedRoles = [...roles.values()].filter(
    (r) => r.id !== guild.id && !r.managed && !r.editable
  );

  console.log(CONFIRM ? '== DELETING ==' : '== DRY RUN (nothing deleted, add --confirm) ==');
  console.log('\nChannels/categories to delete:');
  toDeleteChannels.forEach((c) => console.log('  -', c.name));
  console.log('\nRoles to delete:');
  toDeleteRoles.forEach((r) => console.log('  -', r.name));
  if (skippedRoles.length) {
    console.log('\nRoles I cannot delete (above my role - drag my role higher):');
    skippedRoles.forEach((r) => console.log('  -', r.name));
  }

  if (CONFIRM) {
    for (const c of toDeleteChannels) {
      await c.delete('cleanup').then(() => console.log('deleted channel', c.name)).catch((e) => console.log('FAILED channel', c.name, e.message));
    }
    for (const r of toDeleteRoles) {
      await r.delete('cleanup').then(() => console.log('deleted role', r.name)).catch((e) => console.log('FAILED role', r.name, e.message));
    }
    console.log('\nDone.');
  }
  client.destroy();
});

client.login(process.env.DISCORD_TOKEN);
