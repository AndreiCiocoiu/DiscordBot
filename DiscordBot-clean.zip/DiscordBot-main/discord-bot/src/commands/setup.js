const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ChannelType,
  EmbedBuilder,
} = require('discord.js');
const db = require('../utils/database');
const { toSmallCaps } = require('../utils/fancyFont');

// Reverse of toSmallCaps, so "ᴡᴇʟᴄᴏᴍᴇ" and "welcome" count as the same name.
const SMALL_CAPS_REVERSE = {
  'ᴀ': 'a', 'ʙ': 'b', 'ᴄ': 'c', 'ᴅ': 'd', 'ᴇ': 'e', 'ꜰ': 'f', 'ɢ': 'g', 'ʜ': 'h',
  'ɪ': 'i', 'ᴊ': 'j', 'ᴋ': 'k', 'ʟ': 'l', 'ᴍ': 'm', 'ɴ': 'n', 'ᴏ': 'o', 'ᴘ': 'p',
  'ʀ': 'r', 'ꜱ': 's', 'ᴛ': 't', 'ᴜ': 'u', 'ᴠ': 'v', 'ᴡ': 'w', 'ʏ': 'y', 'ᴢ': 'z',
};

// Comparison key for a channel/category name: drops the emoji/symbol prefix
// (everything up to the "・" separator), un-small-caps it, lowercases it and
// treats spaces and dashes the same. This is what keeps /setup from creating
// duplicates of channels that already exist with a slightly different style.
function nameKey(name) {
  let n = name.includes('・') ? name.split('・').slice(1).join('・') : name;
  n = [...n].map((c) => SMALL_CAPS_REVERSE[c] ?? c).join('');
  return n.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

async function findOrCreateCategory(guild, name) {
  let category = guild.channels.cache.find(
    (c) => c.type === ChannelType.GuildCategory && nameKey(c.name) === nameKey(name)
  );
  if (!category) {
    category = await guild.channels.create({
      name,
      type: ChannelType.GuildCategory,
      reason: 'Server setup via /setup',
    });
  }
  return category;
}

async function findOrCreateChannel(guild, name, type, parent, overwrites = []) {
  let channel = guild.channels.cache.find(
    (c) => c.type === type && c.parentId === parent.id && nameKey(c.name) === nameKey(name)
  );
  if (!channel) {
    channel = await guild.channels.create({
      name,
      type,
      parent: parent.id,
      permissionOverwrites: overwrites,
      reason: 'Server setup via /setup',
    });
  }
  return channel;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Set up the server channels (no roles are created).')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    if (!interaction.inGuild()) {
      return interaction.reply({ content: 'Run this inside a server.', ephemeral: true });
    }

    await interaction.deferReply();
    const guild = interaction.guild;
    const everyone = guild.roles.everyone;

    // Fresh fetch so a stale cache can't cause duplicates.
    await guild.channels.fetch();

    // --- Chill Zone ---
    const chill = await findOrCreateCategory(guild, `💬 ${toSmallCaps('Chill Zone')}`);
    const welcomeChannel = await findOrCreateChannel(
      guild,
      `👋・${toSmallCaps('welcome')}`,
      ChannelType.GuildText,
      chill,
      [{ id: everyone.id, deny: [PermissionFlagsBits.SendMessages], allow: [PermissionFlagsBits.ViewChannel] }]
    );
    const generalChannel = await findOrCreateChannel(guild, `💬・${toSmallCaps('general')}`, ChannelType.GuildText, chill);

    // --- RDR2 Online ---
    const rdr2 = await findOrCreateCategory(guild, `🤠 ${toSmallCaps('RDR2 Online')}`);
    await findOrCreateChannel(guild, `ℹ️・${toSmallCaps('info')}`, ChannelType.GuildText, rdr2);
    await findOrCreateChannel(guild, `💬・${toSmallCaps('rdr2-chat')}`, ChannelType.GuildText, rdr2);
    await findOrCreateChannel(guild, `📬・${toSmallCaps('tabara')}`, ChannelType.GuildText, rdr2);

    // --- Voice ---
    const voice = await findOrCreateCategory(guild, `🔊 ${toSmallCaps('Voice')}`);
    await findOrCreateChannel(guild, `🎵・${toSmallCaps('music')}`, ChannelType.GuildText, voice);
    await findOrCreateChannel(guild, `🎮・${toSmallCaps('Gaming Voice')}`, ChannelType.GuildVoice, voice);
    await findOrCreateChannel(guild, `🔊・${toSmallCaps('General Voice')}`, ChannelType.GuildVoice, voice);
    await findOrCreateChannel(guild, `😴・${toSmallCaps('cuibusor')}`, ChannelType.GuildVoice, voice);
    await findOrCreateChannel(guild, `😴・${toSmallCaps('AFK')}`, ChannelType.GuildVoice, voice);

    db.saveGuildConfig(guild.id, { welcomeChannelId: welcomeChannel.id });

    const embed = new EmbedBuilder()
      .setTitle('Setup done')
      .setColor(0x57f287)
      .setDescription(
        [
          `Channels checked/created: ${welcomeChannel}, ${generalChannel}, rdr2-chat, tabara, info, music and the voice rooms.`,
          'No roles were created.',
          `New members get welcomed in ${welcomeChannel}.`,
        ].join('\n')
      );

    await interaction.editReply({ embeds: [embed] });
  },
};
